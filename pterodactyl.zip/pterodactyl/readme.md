##RexxCloud## Jangan Dihapus Wmnya Su
Jangan Dijual Juga Asu Anak Jb
Nih Tutor Install
> Ekstrak Dulu File Ini Jadi Folder
> Upload File Ini ke /var/www
Comandnya 
$ curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
$ apt install nodejs -y
$ apt install npm -y
$ npm i -g yarn
$ cd /var/www/pterodactyl
$ yarn 
$ php artisan billing:install stable 
 License nya : rexxcloud
$ yarn build:production